export default new Vuex.Store({

    //定义状态
    state: {
        isLogin: false,
        token: ''
    }
});

